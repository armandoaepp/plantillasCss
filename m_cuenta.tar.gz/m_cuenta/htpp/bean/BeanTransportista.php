<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanTransportista{
# Constructor
    public function __construct(){}
# Atributos
    private $idtransp;
    private $razonsocial;
    private $direccion;
    private $telefonos;
    private $telefono2;
    private $telefono3;
    private $email;
    private $avatar;
    private $ruc;
    private $representante;
    private $puntuacion;
    private $permisos;
    private $web;
    private $facebook;
    private $twitter;
    private $fechareg;
    private $estado;
    private $certificada;
    private $ubigeo;
# METODOS
    public function setIdTtransp($idtransp_){ $this->idtransp=$idtransp_;}
    public function getIdTtransp(){ return $this->idtransp;}
    public function setRazonSocial($razonsocial_){ $this->razonsocial=$razonsocial_;}
    public function getRazonSocial(){ return $this->razonsocial;}
    public function setDireccion($direccion_){ $this->direccion=$direccion_;}
    public function getDireccion(){ return $this->direccion;}
    public function setTelefonos($telefonos_){ $this->telefonos=$telefonos_;}
    public function getTelefonos(){ return $this->telefonos;}
    public function setTelefono2($telefono2_){ $this->telefono2=$telefono2_;}
    public function getTelefono2(){ return $this->telefono2;}
    public function setTelefono3($telefono3_){ $this->telefono3=$telefono3_;}
    public function getTelefono3(){ return $this->telefono3;}
    public function setTmail($email_){ $this->email=$email_;}
    public function getTmail(){ return $this->email;}
    public function setAvatar($avatar_){ $this->avatar=$avatar_;}
    public function getAvatar(){ return $this->avatar;}
    public function setRuc($ruc_){ $this->ruc=$ruc_;}
    public function getRuc(){ return $this->ruc;}
    public function setRepresentante($representante_){ $this->representante=$representante_;}
    public function getRepresentante(){ return $this->representante;}
    public function setPuntuacion($puntuacion_){ $this->puntuacion=$puntuacion_;}
    public function getPuntuacion(){ return $this->puntuacion;}
    public function setPermisos($permisos_){ $this->permisos=$permisos_;}
    public function getPermisos(){ return $this->permisos;}
    public function setWeb($web_){ $this->web=$web_;}
    public function getWeb(){ return $this->web;}
    public function setFacebook($facebook_){ $this->facebook=$facebook_;}
    public function getFacebook(){ return $this->facebook;}
    public function setTwitter($twitter_){ $this->twitter=$twitter_;}
    public function getTwitter(){ return $this->twitter;}
    public function setFechareg($fechareg_){ $this->fechareg=$fechareg_;}
    public function getFechareg(){ return $this->fechareg;}
    public function setEstado($estado_){ $this->estado=$estado_;}
    public function getEstado(){ return $this->estado;}
    public function setCertificada($certificada_){ $this->certificada=$certificada_;}
    public function getCertificada(){ return $this->certificada;}
    public function setUbigeo($ubigeo_){ $this->ubigeo=$ubigeo_;}
    public function getUbigeo(){ return $this->ubigeo;}
}
?>