<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanLog{
# Constructor
    public function __construct(){}
# Atributos
    private $idlog;
    private $fecha;
    private $idusuario;
    private $ocurrencia;
# METODOS
    public function setIdLog($idlog_){ $this->idlog=$idlog_;}
    public function getIdLog(){ return $this->idlog;}
    public function setFecha($fecha_){ $this->fecha=$fecha_;}
    public function getFecha(){ return $this->fecha;}
    public function setIdUsuario($idusuario_){ $this->idusuario=$idusuario_;}
    public function getIdUsuario(){ return $this->idusuario;}
    public function setOcurrencia($ocurrencia_){ $this->ocurrencia=$ocurrencia_;}
    public function getOcurrencia(){ return $this->ocurrencia;}
}
?>