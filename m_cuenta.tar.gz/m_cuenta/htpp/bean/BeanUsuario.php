<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanUsuario{
# Constructor
    public function __construct(){}
# Atributos
    private $idusuario;
    private $nombres;
    private $nom_usuario;
    private $pass_usuario;
    private $telefono1;
    private $telefono2;
    private $telefono3;
    private $email;
    private $ubigeo;
    private $fechareg;
    private $idcliente;
    private $estado;
    private $superusuario;
# METODOS
    public function setIdUsuario($idusuario_){ $this->idusuario=$idusuario_;}
    public function getIdUsuario(){ return $this->idusuario;}
    public function setNombres($nombres_){ $this->nombres=$nombres_;}
    public function getNombres(){ return $this->nombres;}
    public function setNomUsuario($nom_usuario_){ $this->nom_usuario=$nom_usuario_;}
    public function getNomUsuario(){ return $this->nom_usuario;}
    public function setPassUsuario($pass_usuario_){ $this->pass_usuario=$pass_usuario_;}
    public function getPassUsuario(){ return $this->pass_usuario;}
    public function setTelefono1($telefono1_){ $this->telefono1=$telefono1_;}
    public function getTelefono1(){ return $this->telefono1;}
    public function setTelefono2($telefono2_){ $this->telefono2=$telefono2_;}
    public function getTelefono2(){ return $this->telefono2;}
    public function setTelefono3($telefono3_){ $this->telefono3=$telefono3_;}
    public function getTelefono3(){ return $this->telefono3;}
    public function setEmail($email_){ $this->email=$email_;}
    public function getEmail(){ return $this->email;}
    public function setUbigeo($ubigeo_){ $this->ubigeo=$ubigeo_;}
    public function getUbigeo(){ return $this->ubigeo;}
    public function setFechaReg($fechareg_){ $this->fechareg=$fechareg_;}
    public function getFechaReg(){ return $this->fechareg;}
    public function setIdCliente($idcliente_){ $this->idcliente=$idcliente_;}
    public function getIdCliente(){ return $this->idcliente;}
    public function setEstado($estado_){ $this->estado=$estado_;}
    public function getEstado(){ return $this->estado;}
    public function setSuperUsuario($superusuario_){ $this->superusuario=$superusuario_;}
    public function getSuperUsuario(){ return $this->superusuario;}
}
?>