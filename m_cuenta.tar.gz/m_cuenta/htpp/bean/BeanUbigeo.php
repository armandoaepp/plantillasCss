<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanUbigeo{
# Constructor
    public function __construct(){}
# Atributos
    private $codubigeo;
    private $lugar;
    private $longitud;
    private $latitud;
# METODOS
    public function setCodUbigeo($codubigeo_){ $this->codubigeo=$codubigeo_;}
    public function getCodUbigeo(){ return $this->codubigeo;}
    public function setLugar($lugar_){ $this->lugar=$lugar_;}
    public function getLugar(){ return $this->lugar;}
    public function setLongitud($longitud_){ $this->longitud=$longitud_;}
    public function getLongitud(){ return $this->longitud;}
    public function setLatitud($latitud_){ $this->latitud=$latitud_;}
    public function getLatitud(){ return $this->latitud;}
}
?>