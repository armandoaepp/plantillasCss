<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanOperador{
# Constructor
    public function __construct(){}
# Atributos
    private $idoperador;
    private $nombre;
    private $nom_operador;
    private $pass_operador;
    private $telefono1;
    private $telefono2;
    private $telefono3;
    private $codubigeo;
    private $fechareg;
    private $idtransp;
    private $estado;
    private $superusuario;
# METODOS
    public function setIdOperador($idoperador_){ $this->idoperador=$idoperador_;}
    public function getIdOperador(){ return $this->idoperador;}
    public function setNombre($nombre_){ $this->nombre=$nombre_;}
    public function getNombre(){ return $this->nombre;}
    public function setNomOperador($nom_operador_){ $this->nom_operador=$nom_operador_;}
    public function getNomOperador(){ return $this->nom_operador;}
    public function setPassOperador($pass_operador_){ $this->pass_operador=$pass_operador_;}
    public function getPassOperador(){ return $this->pass_operador;}
    public function setTelefono1($telefono1_){ $this->telefono1=$telefono1_;}
    public function getTelefono1(){ return $this->telefono1;}
    public function setTelefono2($telefono2_){ $this->telefono2=$telefono2_;}
    public function getTelefono2(){ return $this->telefono2;}
    public function setTelefono3($telefono3_){ $this->telefono3=$telefono3_;}
    public function getTelefono3(){ return $this->telefono3;}
    public function setCodUbigeo($codubigeo_){ $this->codubigeo=$codubigeo_;}
    public function getCodUbigeo(){ return $this->codubigeo;}
    public function setFechaReg($fechareg_){ $this->fechareg=$fechareg_;}
    public function getFechaReg(){ return $this->fechareg;}
    public function setIdTransp($idtransp_){ $this->idtransp=$idtransp_;}
    public function getIdTransp(){ return $this->idtransp;}
    public function setEstado($estado_){ $this->estado=$estado_;}
    public function getEstado(){ return $this->estado;}
    public function setSuperUsuario($superusuario_){ $this->superusuario=$superusuario_;}
    public function getSuperUsuario(){ return $this->superusuario;}
}
?>