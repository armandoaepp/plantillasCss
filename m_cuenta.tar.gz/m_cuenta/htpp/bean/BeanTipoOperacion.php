<?php
# Clase Bean Generada  - Creado por @armandoaepp
class BeanTipoOperacion{
# Constructor
    public function __construct(){}
# Atributos
    private $idtipo_operacion;
    private $descripcion;
# METODOS
    public function setIdTipoOperacion($idtipo_operacion_){ $this->idtipo_operacion=$idtipo_operacion_;}
    public function getIdTipoOperacion(){ return $this->idtipo_operacion;}
    public function setDescripcion($descripcion_){ $this->descripcion=$descripcion_;}
    public function getDescripcion(){ return $this->descripcion;}
}
?>