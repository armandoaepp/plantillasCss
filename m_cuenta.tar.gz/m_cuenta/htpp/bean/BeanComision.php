<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanComision{
# Constructor
    public function __construct(){}
# Atributos
    private $idcomision;
    private $gc;
    private $gc_urg;
    private $tra;
    private $igv;
# METODOS
    public function setIdComision($idcomision_){ $this->idcomision=$idcomision_;}
    public function getIdComision(){ return $this->idcomision;}
    public function setGc($gc_){ $this->gc=$gc_;}
    public function getGc(){ return $this->gc;}
    public function setGcUrg($gc_urg_){ $this->gc_urg=$gc_urg_;}
    public function getGcUrg(){ return $this->gc_urg;}
    public function setTra($tra_){ $this->tra=$tra_;}
    public function getTra(){ return $this->tra;}
    public function setIgv($igv_){ $this->igv=$igv_;}
    public function getIgv(){ return $this->igv;}
}
?>