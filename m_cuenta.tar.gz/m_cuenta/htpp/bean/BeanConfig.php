<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanConfig{
# Constructor
    public function __construct(){}
# Atributos
    private $idconfig;
    private $idtipoentidad;
    private $idvalor;
    private $valor;
    private $referencia;
    private $estado;
# METODOS
    public function setIdconfig($idconfig_){ $this->idconfig=$idconfig_;}
    public function getIdconfig(){ return $this->idconfig;}
    public function setIdTipoEntidad($idtipoentidad_){ $this->idtipoentidad=$idtipoentidad_;}
    public function getIdTipoEntidad(){ return $this->idtipoentidad;}
    public function setIdValor($idvalor_){ $this->idvalor=$idvalor_;}
    public function getIdValor(){ return $this->idvalor;}
    public function setValor($valor_){ $this->valor=$valor_;}
    public function getValor(){ return $this->valor;}
    public function setReferencia($referencia_){ $this->referencia=$referencia_;}
    public function getReferencia(){ return $this->referencia;}
    public function setEstado($estado_){ $this->estado=$estado_;}
    public function getEstado(){ return $this->estado;}
}
?>