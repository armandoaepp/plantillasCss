<?php 
# Clase Bean Generada  - Creado por @armandoaepp 
class BeanGc{
# Constructor
    public function __construct(){}
# Atributos
    private $idgc;
    private $razonsocial;
    private $direccion;
    private $telefonos;
    private $telefono2;
    private $telefono3;
    private $email;
    private $avatar;
    private $tipodoc;
    private $numerodoc;
    private $representante;
    private $tipo;
    private $lugar;
    private $fechareg;
    private $estado;
    private $requisitos;
# METODOS
    public function setIdGc($idgc_){ $this->idgc=$idgc_;}
    public function getIdGc(){ return $this->idgc;}
    public function setRazonsocial($razonsocial_){ $this->razonsocial=$razonsocial_;}
    public function getRazonsocial(){ return $this->razonsocial;}
    public function setDireccion($direccion_){ $this->direccion=$direccion_;}
    public function getDireccion(){ return $this->direccion;}
    public function setTelefonos($telefonos_){ $this->telefonos=$telefonos_;}
    public function getTelefonos(){ return $this->telefonos;}
    public function setTelefono2($telefono2_){ $this->telefono2=$telefono2_;}
    public function getTelefono2(){ return $this->telefono2;}
    public function setTelefono3($telefono3_){ $this->telefono3=$telefono3_;}
    public function getTelefono3(){ return $this->telefono3;}
    public function setEmail($email_){ $this->email=$email_;}
    public function getEmail(){ return $this->email;}
    public function setAvatar($avatar_){ $this->avatar=$avatar_;}
    public function getAvatar(){ return $this->avatar;}
    public function setTipoDoc($tipodoc_){ $this->tipodoc=$tipodoc_;}
    public function getTipoDoc(){ return $this->tipodoc;}
    public function setNumeroDoc($numerodoc_){ $this->numerodoc=$numerodoc_;}
    public function getNumeroDoc(){ return $this->numerodoc;}
    public function setRepresentante($representante_){ $this->representante=$representante_;}
    public function getRepresentante(){ return $this->representante;}
    public function setTipo($tipo_){ $this->tipo=$tipo_;}
    public function getTipo(){ return $this->tipo;}
    public function setLugar($lugar_){ $this->lugar=$lugar_;}
    public function getLugar(){ return $this->lugar;}
    public function setFechaReg($fechareg_){ $this->fechareg=$fechareg_;}
    public function getFechaReg(){ return $this->fechareg;}
    public function setEstado($estado_){ $this->estado=$estado_;}
    public function getEstado(){ return $this->estado;}
    public function setRequisitos($requisitos_){ $this->requisitos=$requisitos_;}
    public function getRequisitos(){ return $this->requisitos;}
}
?>